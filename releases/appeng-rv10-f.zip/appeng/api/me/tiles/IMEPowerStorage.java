package appeng.api.me.tiles;

public interface IMEPowerStorage {

	boolean useMEEnergy( float use, String for_what );
//	boolean useMEEnergy( float use );
	
}
