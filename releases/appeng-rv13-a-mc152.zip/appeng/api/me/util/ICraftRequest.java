package appeng.api.me.util;

/**
 * Pretty much just a place holder right now
 *
 */
public interface ICraftRequest {

}
