package appeng.api.me.items;

/**
 * Like IAssemblerPatternItem, not really useful...
 */
public interface ILocationPatternItem {
}
