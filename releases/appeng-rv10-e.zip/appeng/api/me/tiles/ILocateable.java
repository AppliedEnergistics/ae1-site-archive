package appeng.api.me.tiles;

public interface ILocateable
{
	long getLocatableSerial();
}
